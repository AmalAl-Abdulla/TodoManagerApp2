package cmps312.qu.edu.qa.todomanagerapp2;

public class TodoItems {

    private String title;
    private int status;
    private int priority;
    private String date;
    private String time;

    public TodoItems() {
        this.title = "";
        this.status = 0;
        this.priority = 0;
        this.date = "";
        this.time = "";
    }

    public TodoItems(String title, int status, int priority, String date, String time) {
        this.title = title;
        this.status = status;
        this.priority = priority;
        this.date = date;
        this.time = time;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
