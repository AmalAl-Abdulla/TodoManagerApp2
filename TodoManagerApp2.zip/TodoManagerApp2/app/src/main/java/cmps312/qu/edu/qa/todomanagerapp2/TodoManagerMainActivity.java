package cmps312.qu.edu.qa.todomanagerapp2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class TodoManagerMainActivity extends Activity {
    ListView listViewItems;
    Button buttonAddItems;
    ArrayList<TodoItems> getListItems;
    TextView textViewTitle ;
    TextView textViewPriority ;
    CheckBox checkBoxStatus, checkBoxDelete;
    TextView textViewTime;
    TextView textViewDate ;
    TodoManagerAdapter todoManagerAdapter;
    DBHelper database;
    Cursor cursor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_manager_main);
        listViewItems = (ListView) findViewById(R.id.items_list);
        database = new DBHelper(this);
//        database.addItem("Play sport",0,2,"28/12/2003","6:34");
        cursor = database.getAllItems();
        getListItems = new ArrayList<>();
        todoManagerAdapter =new TodoManagerAdapter(this, cursor);
        listViewItems.setAdapter(todoManagerAdapter);
        buttonAddItems = (Button) findViewById(R.id.add_items_button);
        buttonAddItems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(TodoManagerMainActivity.this, TodoItemsActivity.class);
                startActivityForResult(i, 101);
            }
        });
    }

    class TodoManagerAdapter extends CursorAdapter {

        //constructor
        public TodoManagerAdapter(Context c, Cursor cursor) {
            super(c,cursor,0);
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
            return LayoutInflater.from(context).inflate(R.layout.items_list_row,null);
        }

        @Override
        public void bindView(final View view, final Context context, final Cursor cursor) {


            textViewTitle = view.findViewById(R.id.row_title_text_view);
            checkBoxStatus = view.findViewById(R.id.row_status_check_box);
            textViewPriority = view.findViewById(R.id.row_priority_text_view);
            textViewDate = view.findViewById(R.id.row_date_text_view);
            textViewTime = view.findViewById(R.id.row_time_text_view);
            checkBoxDelete = view.findViewById(R.id.row_delete_check_box);

            String title = cursor.getString(1);
            final int status = cursor.getInt(2);
            final int priority = cursor.getInt(3);
            String time = cursor.getString(4);
            String date = cursor.getString(5);


            textViewTitle.setText(title);
            if(status==0)  //not done
                checkBoxStatus.setChecked(false);
             else if(status==1)  //done
                checkBoxStatus.setChecked(true);
             if(priority ==0) //low
                textViewPriority.setText("LOW");
            else if(priority ==1) //medium
                textViewPriority.setText("MEDIUM");
            else if(priority ==2) //high
                textViewPriority.setText("HIGH");
            textViewDate.setText(date);
            textViewTime.setText(time);


            checkBoxStatus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    if(compoundButton.isChecked())
                        view.setBackgroundColor(Color.LTGRAY);
                    else
                        view.setBackgroundColor(Color.TRANSPARENT);
                }
            });

            view.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    //opens a dialog that has the same TodoItemsActivity layout
                    View dialogView = getLayoutInflater().inflate(R.layout.alert_dialog_view,null);
                    TextView delete = (TextView) dialogView.findViewById(R.id.delete_dialog);
                    final TextView edit = (TextView) dialogView.findViewById(R.id.edit_dialog);
                    delete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            database.deleteItems(cursor.getPosition());
                            todoManagerAdapter.notifyDataSetChanged();
                        }
                    });
                    edit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            View editDialogView = LayoutInflater.from(context)
                                    .inflate(R.layout.edit_activity_todo_items,null);

                            EditText editTextTitle;
                            RadioGroup radioGroupStatus, radioGroupPriority;
                            Button buttonDate, buttonTime, buttonUpdate,buttonCancel,buttonReset;
                            TextView textViewDate, textViewTime;

                            editTextTitle = (EditText) editDialogView.findViewById(R.id.edit_text_title_2);
                            radioGroupPriority = (RadioGroup) editDialogView.findViewById(R.id.priority_radio_group_2);
                            radioGroupStatus = (RadioGroup) editDialogView.findViewById(R.id.status_radio_group_2);
                            buttonDate = (Button) editDialogView.findViewById(R.id.date_button_2);
                            buttonTime = (Button) editDialogView.findViewById(R.id.time_button_2);
                            textViewDate = (TextView) editDialogView.findViewById(R.id.date_format_label_2);
                            textViewTime = (TextView) editDialogView.findViewById(R.id.time_format_label_2);
                            int priorityUpdate = 0, statusUpdate =0;

                            for(int i=0;i<radioGroupPriority.getChildCount();i++)
                                priorityUpdate = Integer.parseInt(radioGroupPriority.getChildAt(i).toString());
                            for(int i=0;i<radioGroupStatus.getChildCount();i++)
                                statusUpdate = Integer.parseInt(radioGroupStatus.getChildAt(i).toString());

                            database.updateItem(editTextTitle.getText().toString()
                                    ,statusUpdate
                                    ,priorityUpdate
                                    ,textViewDate.getText().toString()
                                    ,textViewTime.getText().toString());
                            todoManagerAdapter.notifyDataSetChanged();


                        }
                    });

                    new AlertDialog.Builder(context)
                            .setView(dialogView)
                            .show();

                    return true;
                }
            });
        }


    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) { //request code is for activities
        super.onActivityResult(requestCode, resultCode, data);


            if(resultCode == Activity.RESULT_OK) {
                String title = data.getStringExtra(TodoItemsActivity.TITLE);
                String date = data.getStringExtra(TodoItemsActivity.DATE);
                String time = data.getStringExtra(TodoItemsActivity.TIME);
                int status = data.getIntExtra(TodoItemsActivity.STATUS, 0);
                int priority = data.getIntExtra(TodoItemsActivity.PRIORITY, 0);
                database.addItem(title,status,priority,date,time);
                todoManagerAdapter.notifyDataSetChanged();

        }
    }

}


