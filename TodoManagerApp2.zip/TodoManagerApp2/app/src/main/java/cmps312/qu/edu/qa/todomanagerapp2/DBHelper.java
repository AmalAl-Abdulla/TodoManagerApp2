package cmps312.qu.edu.qa.todomanagerapp2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;


public class DBHelper extends SQLiteOpenHelper {
    final static String DATABASE_NAME = "todoItemsDataBase";
    final static int DATABASE_VERSION = 3;
    final static String TABLE_TODOITEMS = "todoItemsTable";
    final static String COLUMN_ID = "id";
    final static String COLUMN_TITLE = "title";
    final static String COLUMN_STATUS = "status";
    final static String COLUMN_PRIORITY = "priority";
    final static String COLUMN_DATE = "date";
    final static String COLUMN_TIME = "time";

    public DBHelper(Context context){
        super(context, DATABASE_NAME,null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String sqlCreate = "create table "
                + TABLE_TODOITEMS +" ( "
                + COLUMN_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_TITLE+" TEXT ,"
                + COLUMN_STATUS+" INTEGER,"
                + COLUMN_PRIORITY+" INTEGER,"
                + COLUMN_DATE+" TEXT,"
                + COLUMN_TIME+" TEXT" +" )";
        sqLiteDatabase.execSQL(sqlCreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists "+TABLE_TODOITEMS);
        onCreate(sqLiteDatabase);
    }


    public void addItem(String title, int status, int priority, String date, String time) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE,title);
        values.put(COLUMN_STATUS,status);
        values.put(COLUMN_PRIORITY,priority);
        values.put(COLUMN_DATE,date);
        values.put(COLUMN_TIME,time);
        database.insert(TABLE_TODOITEMS,null,values);
        database.close();
    }

    public Cursor getItem(String title){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from"+TABLE_TODOITEMS+" where "
                +COLUMN_TITLE+" ="+title,null);
        return cursor;
    }
    public Cursor getAllItems(){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from "+TABLE_TODOITEMS,null);
        return cursor;
    }

    public boolean updateItem(String title, int status, int priority, String date, String time){
     SQLiteDatabase database = this.getReadableDatabase();
     ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE,title);
        values.put(COLUMN_STATUS,status);
        values.put(COLUMN_PRIORITY,priority);
        values.put(COLUMN_DATE,date);
        values.put(COLUMN_TIME,time);
        database.update(TABLE_TODOITEMS,values," id = ?",new String[]{title});
        return true;
    }

    public int deleteItems(int position){
        SQLiteDatabase database = this.getReadableDatabase();
        return database.delete(TABLE_TODOITEMS," id = ?", new String[] {String.valueOf(position)});
    }



}
